
The clipper.py file included in this distribution contains a very old version of Clipper.

I found it too onerous maintaining 4 parallel translations of Clipper, and I only wrote clipper.py to teach myself Python. 
Besides, the Python code is about 100 times slower than compiled versions of Clipper so there are better alternatives.

Maxime Chalon <maxime.chalon@gmail.com> has written a Python extension module for Clipper:
https://sites.google.com/site/maxelsbackyard/home/pyclipper
This module provides a Python interface to the C++ compiled Clipper Library.

